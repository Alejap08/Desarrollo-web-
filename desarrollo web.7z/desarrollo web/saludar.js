
export const Saludar = (nombre) => {
    return `Buenos días, ${nombre}`;
}

export const pedirAyuda =() => 'Ayuda';

export const IniciarJ =(incio) => {
    return `INICIAR EL JUEGO, ${incio}`;
}