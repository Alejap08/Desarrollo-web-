//import {pi} from './math.js';
//import {IniciarJ, Saludar} from './saludar.js';

//console.log(Saludar('Juan'));
//console.log(pi);

//console.log (IniciarJ('EN MINUTOS VA'))
//const titulo = document.getElementById('Titulo');

//titulo.innerHTML = 'BIENVENIDO';

//const titulo = document.getElementById('Titulo1');

//titulo.innerHTML = 'PIEDRA';

//const titulo = document.getElementById('principal');

//titulo.innerHTML = 'BIENVENIDOS AL JUEGO';//

import {generateComputersChoice,getResult} from "./prueba.js";